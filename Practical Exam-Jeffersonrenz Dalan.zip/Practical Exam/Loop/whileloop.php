<!DOCTYPE html>
<html>
<body>


<?php
	
$x=1;
$sum=0;
while($x<=10){
    if($x%2==0)
    $sum+=$x;
$x++;


}

echo "The sum of even numbers from 0 to 10 is".$sum;
	
  
?>
</body>
</html>