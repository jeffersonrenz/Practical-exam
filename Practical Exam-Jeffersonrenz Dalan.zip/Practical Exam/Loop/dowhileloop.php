<!DOCTYPE html>
<html>
<body>

<?php

$x=1;
echo "The odd numbers from 0 to 10 are ";
do{

  if ($x%2!=0)
    echo $x.", ";
$x++;


}while($x<=10);

?>
  
</body>
</html>
