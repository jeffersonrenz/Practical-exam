<!DOCTYPE html>
<html>
<body>

<?php
  
$x;
$char = array(red,blue,black,red,blue,blue,red,gold);

function display_nonr($char, $n)
{
    for ($i = 0; $i < $n; $i++)
    {
        for ($x = 0; $x < $n; $x++)
            if ($i != $x && $char[$i] == $char[$x])
                break;
        if ($x == $n)
            return $char[$i];
    }
    return -1;
}
    $n = sizeof($char);
    echo "Item not repetitive: " .display_nonr($char, $n);
      
?>
</body>
</html>
