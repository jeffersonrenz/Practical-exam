<!DOCTYPE html>
<html>
<body>

<?php
$names = array(Marvin, Marco, Marvin, Marco, Marco, Marvin, Christian);
sort($names);


echo "Number of String Occurences: ";
echo "<br>";
print_r(array_count_values($names));
echo "<br>";
echo "<br>";

echo "Alphabetical Arrangement Order:";
echo "<br>";


$length = count($names);
for($x = 0; $x < $length; $x++) {
	$names = array_unique($names);
  	echo $names[$x];
  	echo "<br>";
}

?>

</body>
</html>