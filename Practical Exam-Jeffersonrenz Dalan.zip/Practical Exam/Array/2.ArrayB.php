<!DOCTYPE html>
<html>
<body>
  
<?php
$nums = array(9863,7127,2020,80,131,55,100);
sort($nums);
  
    
$length = count($nums);
for($x = 0; $x < $length; $x++) {
    echo $nums[$x];
    echo "<br>";
}
?>
  
</body>
</html>
